sudo docker build -t challenge2 .
sudo docker run -d -p 5050:5050 challenge2