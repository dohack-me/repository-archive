# Fatherboat 3.0

With all the shiny new tech like **NiceGUI** and **EdgeDB**, surely my website can't be pwned again??

First part of the flag is in the web app, second part is in the database.
